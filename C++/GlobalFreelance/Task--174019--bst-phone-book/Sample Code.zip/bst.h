#ifndef _BST
#define _BST

#include <iostream>
#include <vector>

class node
{
public:
	node() { data = 0;left = nullptr;right = nullptr; }
	node(int i) {data = i;left = nullptr;right = nullptr;}
	int data;
	node *left;
	node *right;
};


class BSTree
{
public:
	BSTree();
	~BSTree();
	node* findParent(node *child,node*root);
	bool findNode(int i);
	bool insertNode(int i);
	int displayCurrent();
	void outputSortList();
	void sortList(node *root);
	int  findSmallDecendent(node*decendent);

	void deleteCurrent();
	
private:
	node *Root;
	node *current;
	bool find(int i, node *root);
	bool insert(int i, node *root);
	void deleteAll(node *root);

	void deleteNode(node *toDelete);
};

#endif
